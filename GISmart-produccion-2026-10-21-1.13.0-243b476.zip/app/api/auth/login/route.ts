import { type NextRequest, NextResponse } from "next/server"
import { emitirToken, llegoPorHttps, ponerCookieDeSesion, secretoValido, verificarToken, vieneDeOtroSitio } from "@/lib/auth-server"
import { clienteSupabase } from "@/lib/supabase-servidor"
import { esHash, hashClave, verificarClave, HASH_SENUELO } from "@/lib/password"
import { tieneInvisibles } from "@/lib/texto"

// Los usuarios reales viven en `public.usuario_app`. La tabla se recreó en
// septiembre de 2026 con otras columnas: antes eran id_usr, codigo, nombre,
// clave y activo; ahora `nombre_usuario` (clave primaria, con él se entra),
// `nombre_completo`, `correo`, `clave` y `activo`.
// Las contraseñas se guardan con hash scrypt (ver lib/password.ts). Las que
// quedaran en texto plano siguen funcionando y se migran solas la primera vez
// que esa persona inicia sesión.
type UsuarioApp = {
  nombre_usuario: string
  nombre_completo: string | null
  clave: string
  activo: boolean
}

/** Las columnas que se piden, en un solo sitio para que no se desincronicen. */
const COLUMNAS_USUARIO = "nombre_usuario, nombre_completo, clave, activo"

// Sin columna de rol todavía en usuario_app: se asigna uno genérico hasta
// que exista esa información real.
const ROL_POR_DEFECTO = "usuario"

/** El cuerpo de un inicio de sesión no pasa de unos cientos de bytes. */
const MAX_BYTES_CUERPO = 10_000

const MAX_INTENTOS = 5
const BLOQUEO_MS = 30_000
/** Tras este tiempo sin actividad se olvida el historial de una cuenta. */
const OLVIDO_MS = 15 * 60_000
/** Tope de cuentas vigiladas a la vez, por si la limpieza por tiempo no basta. */
const MAX_VIGILADAS = 5_000

/**
 * Intentos fallidos por usuario, en memoria del proceso.
 *
 * Se limpia sola. Antes no: como la clave es el nombre que llega en la
 * petición, bastaba con mandar nombres distintos —existan o no— para que el
 * mapa creciera sin techo hasta agotar la memoria del servidor.
 */
const intentos = new Map<string, { fallos: number; bloqueadaHasta: number; visto: number }>()
let proximaLimpieza = 0

function limpiarIntentos(ahora: number) {
  // Recorrer el mapa en cada login sería gasto inútil: se hace como mucho una
  // vez por minuto, o de inmediato si ya se pasó del tope.
  if (ahora < proximaLimpieza && intentos.size <= MAX_VIGILADAS) return
  proximaLimpieza = ahora + 60_000

  for (const [nombre, registro] of intentos) {
    if (registro.bloqueadaHasta <= ahora && ahora - registro.visto > OLVIDO_MS) {
      intentos.delete(nombre)
    }
  }

  // Si aun así sobran (una ráfaga muy grande en poco tiempo), se sueltan las
  // más antiguas: `Map` conserva el orden de inserción.
  let sobran = intentos.size - MAX_VIGILADAS
  if (sobran <= 0) return
  for (const [nombre, registro] of intentos) {
    if (sobran <= 0) break
    // Una cuenta bloqueada no se suelta: antes, mandar miles de nombres
    // inventados la sacaba del mapa y quedaba desbloqueada. Los bloqueos duran
    // 30 s, así que el mapa no crece sin techo por esto.
    if (registro.bloqueadaHasta > ahora) continue
    intentos.delete(nombre)
    sobran--
  }
}

/**
 * El cuerpo de la petición, leído hasta `max` bytes; `null` si es más grande,
 * y ahí se deja de leer. `req.text()` lo leía entero aunque no dijera su tamaño
 * (envío por partes): 256 MB ocupaban 1 GB de memoria antes de responder 413.
 */
async function leerConTope(req: Request, max: number): Promise<string | null> {
  if (!req.body) return ""
  const lector = req.body.getReader()
  const partes: Uint8Array[] = []
  let total = 0
  try {
    for (;;) {
      const { done, value } = await lector.read()
      if (done) break
      total += value.byteLength
      if (total > max) {
        await lector.cancel().catch(() => {})
        return null
      }
      partes.push(value)
    }
  } catch {
    return ""
  }
  const todo = new Uint8Array(total)
  let posicion = 0
  for (const parte of partes) {
    todo.set(parte, posicion)
    posicion += parte.byteLength
  }
  return new TextDecoder().decode(todo)
}

/**
 * Escapa los comodines de LIKE para que el nombre se busque tal cual.
 *
 * `ilike` interpreta `%` y `_` como comodines, y PostgREST además traduce `*`
 * a `%`. Al pasar el nombre sin escapar, enviar `%` traía todas las cuentas y
 * `_____` las de cinco letras: cualquiera podía averiguar qué usuarios existen
 * sin saber ninguna contraseña. El backslash es el escape por defecto de
 * PostgreSQL, así que también hay que escaparlo a él.
 */
function escaparComodines(valor: string): string {
  return valor.replace(/[\\%_*]/g, (caracter) => `\\${caracter}`)
}

export async function POST(req: NextRequest) {
  // Otra página no puede iniciar una sesión aquí por el navegador de alguien.
  if (vieneDeOtroSitio(req)) {
    return NextResponse.json({ message: "Solicitud no permitida.", field: null }, { status: 403 })
  }
  // Un secreto débil en producción se detecta aquí, antes de consultar la base y
  // de calcular la clave: antes fallaba al final, con la clave correcta, como
  // un error 500 sin explicación.
  if (!process.env.SUPABASE_URL || !process.env.SUPABASE_SECRET_KEY || !secretoValido()) {
    return NextResponse.json(
      { message: "El servidor de autenticación no está configurado. Revisa .env.local.", field: null },
      { status: 500 },
    )
  }

  // Un usuario y una clave caben en unos cientos de bytes: un cuerpo de varios
  // megas no tiene por qué leerse ni interpretarse.
  if (Number(req.headers.get("content-length") ?? 0) > MAX_BYTES_CUERPO) {
    return NextResponse.json({ message: "Solicitud demasiado grande.", field: null }, { status: 413 })
  }
  const texto = await leerConTope(req, MAX_BYTES_CUERPO)
  if (texto === null) {
    return NextResponse.json({ message: "Solicitud demasiado grande.", field: null }, { status: 413 })
  }
  let body: unknown = null
  try {
    body = JSON.parse(texto)
  } catch {
    // Queda en null: «Solicitud inválida».
  }

  if (!body || typeof body !== "object") {
    return NextResponse.json({ message: "Solicitud inválida.", field: null }, { status: 400 })
  }

  const campos = body as { usuario?: unknown; contrasena?: unknown; recordar?: unknown }
  const usuario = typeof campos.usuario === "string" ? campos.usuario.trim() : ""
  const contrasena = typeof campos.contrasena === "string" ? campos.contrasena : ""
  const recordar = campos.recordar === true

  // Validaciones de servidor (defensa en profundidad)
  if (!usuario) {
    return NextResponse.json({ message: "El usuario es obligatorio.", field: "usuario" }, { status: 400 })
  }
  // Saltos de línea, el carácter nulo o marcas de dirección (U+202E da vuelta
  // el texto) no van en un nombre de usuario: se ven igual y no coinciden.
  if (tieneInvisibles(usuario)) {
    return NextResponse.json(
      { message: "El usuario tiene caracteres que no se pueden usar.", field: "usuario" },
      { status: 400 },
    )
  }
  if (usuario.length < 3) {
    return NextResponse.json(
      { message: "El usuario debe tener al menos 3 caracteres.", field: "usuario" },
      { status: 400 },
    )
  }
  // Tope de largo: sin él, el nombre entra completo en la clave del mapa de
  // intentos y en la consulta, y no hay razón para admitir nombres enormes.
  if (usuario.length > 120) {
    return NextResponse.json(
      { message: "El usuario no puede superar los 120 caracteres.", field: "usuario" },
      { status: 400 },
    )
  }
  if (!contrasena) {
    return NextResponse.json({ message: "La contraseña es obligatoria.", field: "contrasena" }, { status: 400 })
  }
  // scrypt trabaja sobre la contraseña entera: sin tope, una contraseña de
  // varios megas obliga al servidor a derivarla igualmente.
  if (contrasena.length > 200) {
    return NextResponse.json(
      { message: "La contraseña no puede superar los 200 caracteres.", field: "contrasena" },
      { status: 400 },
    )
  }

  // Bloqueo por intentos fallidos
  const ahora = Date.now()
  limpiarIntentos(ahora)
  const clave = usuario.toLowerCase()
  const registro = intentos.get(clave)
  if (registro && registro.bloqueadaHasta > ahora) {
    const segundos = Math.ceil((registro.bloqueadaHasta - ahora) / 1000)
    return NextResponse.json(
      {
        message: `Cuenta bloqueada temporalmente. Intenta de nuevo en ${segundos}s.`,
        field: null,
        lockedUntil: registro.bloqueadaHasta,
      },
      { status: 429 },
    )
  }

  // El intento se cuenta ya, antes del primer `await`: si se cuenta al fallar,
  // muchas peticiones a la vez leen todas el mismo registro viejo, pasan el
  // bloqueo y el contador queda en 1 (se podían probar cientos de claves cada
  // 30 s). Si la clave resulta buena, o la base falla, el intento se devuelve.
  const fallos = (registro?.fallos ?? 0) + 1
  const bloquear = fallos >= MAX_INTENTOS
  intentos.set(
    clave,
    bloquear ? { fallos: 0, bloqueadaHasta: ahora + BLOQUEO_MS, visto: ahora } : { fallos, bloqueadaHasta: 0, visto: ahora },
  )

  /** Deshace la cuenta de este intento (la base falló o la cuenta está inactiva: no fue una clave errada). */
  function devolverIntento() {
    const actual = intentos.get(clave)
    if (!actual) return
    if (bloquear && actual.bloqueadaHasta === ahora + BLOQUEO_MS) {
      intentos.set(clave, { fallos: MAX_INTENTOS - 1, bloqueadaHasta: 0, visto: ahora })
    } else if (actual.bloqueadaHasta === 0 && actual.fallos > 0) {
      intentos.set(clave, { ...actual, fallos: actual.fallos - 1 })
    }
  }

  function registrarFalloDeAcceso() {
    const restantes = MAX_INTENTOS - fallos
    if (bloquear) {
      return NextResponse.json(
        {
          message: "Demasiados intentos fallidos. Cuenta bloqueada 30 segundos.",
          field: null,
          lockedUntil: ahora + BLOQUEO_MS,
        },
        { status: 429 },
      )
    }
    return NextResponse.json(
      {
        message: `Usuario o contraseña incorrectos. Te ${restantes === 1 ? "queda" : "quedan"} ${restantes} ${restantes === 1 ? "intento" : "intentos"}.`,
        field: null,
      },
      { status: 401 },
    )
  }

  // Ya se comprobó arriba que las variables están; el `!` solo lo dice a TypeScript.
  const supabase = clienteSupabase()!

  const { data: cuenta, error } = await supabase
    .from("usuario_app")
    .select(COLUMNAS_USUARIO)
    .ilike("nombre_usuario", escaparComodines(usuario))
    .maybeSingle<UsuarioApp>()

  if (error) {
    // Antes este fallo no dejaba rastro: en la terminal solo aparecía
    // «POST /api/auth/login 502» y había que adivinar la causa. Cuando se
    // recreó usuario_app, el motivo real era una columna que ya no existía
    // (42703) y un permiso perdido (42501).
    console.error(`[login] usuario_app: ${error.code} ${error.message}`)
    devolverIntento()
    return NextResponse.json(
      {
        message:
          error.code === "42501"
            ? "El servidor no tiene permiso para leer los usuarios. Avisa al administrador de la base."
            : "No se pudo conectar con la base de datos. Intenta de nuevo.",
        // Solo en desarrollo: en producción esto se ve antes de iniciar sesión.
        ...(process.env.NODE_ENV === "production" ? {} : { detalle: `usuario_app → ${error.code}: ${error.message}` }),
        field: null,
      },
      { status: 502 },
    )
  }

  // Segunda comprobación del nombre, ya en memoria: `ilike` sigue siendo una
  // comparación por patrón y esto la convierte en una igualdad exacta sin
  // distinguir mayúsculas, pase lo que pase con el escapado.
  const cuentaValida = cuenta && cuenta.nombre_usuario.toLowerCase() === clave ? cuenta : null

  // Se verifica siempre, exista la cuenta o no: si no hay contra qué comparar
  // se usa el hash señuelo, que cuesta lo mismo. Antes se salía sin verificar
  // y un nombre inexistente respondía en ~0 ms frente a los ~55 ms de uno
  // real, lo que permitía averiguar qué usuarios existen.
  const claveValida = await verificarClave(contrasena, cuentaValida?.clave || HASH_SENUELO)
  if (!cuentaValida || !claveValida) {
    return registrarFalloDeAcceso()
  }

  if (!cuentaValida.activo) {
    devolverIntento()
    return NextResponse.json(
      { message: "Este usuario está inactivo. Contacta a un administrador.", field: null },
      { status: 403 },
    )
  }

  // Éxito: limpia intentos
  intentos.delete(clave)

  // Migración transparente: si la contraseña estaba en texto plano, se
  // reemplaza por su hash ahora que sabemos que es la correcta. Así las
  // cuentas se migran solas a medida que la gente entra, sin dejar a nadie
  // fuera ni tener que coordinar un cambio masivo.
  //
  // Es "el mejor esfuerzo": si el UPDATE falla (falta el permiso, o la columna
  // sigue siendo varchar(12) y el hash no cabe), se registra y el login
  // continúa. Nadie se queda sin entrar por esto.
  if (!esHash(cuentaValida.clave ?? "")) {
    try {
      const { error: errorMigracion } = await supabase
        .from("usuario_app")
        .update({ clave: await hashClave(contrasena) })
        .eq("nombre_usuario", cuentaValida.nombre_usuario)

      if (errorMigracion) {
        console.error(
          `[login] No se pudo migrar la clave de "${cuentaValida.nombre_usuario}" a hash: ${errorMigracion.message}`,
        )
      }
    } catch (e) {
      console.error(`[login] Fallo inesperado al migrar la clave a hash:`, e)
    }
  }

  // El token va en una cookie httpOnly y no en el cuerpo: así el JavaScript
  // de la página nunca lo tiene. Al navegador le llega solo lo que muestra y
  // cuándo vence, para avisar a tiempo.
  const token = emitirToken(cuentaValida.nombre_usuario, ROL_POR_DEFECTO)
  const respuesta = NextResponse.json({
    user: {
      usuario: cuentaValida.nombre_usuario,
      role: ROL_POR_DEFECTO,
      // El nombre para mostrar; si viene vacío, el de usuario.
      nombre: cuentaValida.nombre_completo || cuentaValida.nombre_usuario,
    },
    expira: (verificarToken(token)?.exp ?? 0) * 1000,
  })
  ponerCookieDeSesion(respuesta, token, { recordar, https: llegoPorHttps(req) })
  return respuesta
}
