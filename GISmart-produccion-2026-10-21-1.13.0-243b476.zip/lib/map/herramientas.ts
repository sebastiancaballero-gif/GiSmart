import { FIBER_HINT } from "@/lib/map/symbology"

/**
 * Las herramientas del mapa y lo que hay que decir de cada una.
 *
 * Vive fuera del componente porque no depende de nada suyo: son datos fijos que
 * consultan tanto la barra de herramientas como los atajos de teclado, y el
 * ribbon las activa desde fuera.
 */
export type MapTool =
  | "pan"
  | "edit"
  | "node"
  | "fiber"
  | "zone"
  | "delete"
  | "measure-length"
  | "measure-area"
  /**
   * Consulta de conectividad: se activa desde el ribbon (Consultas → Red →
   * «Conectividad fina»), no desde la barra lateral, así que no está en
   * `TOOL_ORDER` ni tiene atajo de teclado.
   */
  | "conectividad"
  /**
   * Entradas y salidas: deja pintados los cables de la mufa pulsada,
   * con el sentido y el color que devuelve la función de cables de la base.
   * También se activa desde el ribbon (Consultas → Red) y tampoco tiene atajo.
   */
  | "sentido"
  /**
   * Consulta de un cable: lo pinta de rojo y marca sus dos mufas, la de
   * entrada (padre) y la de salida (hija). Se activa desde el ribbon
   * (Consultas → Red) y no tiene atajo.
   */
  | "cable"

/**
 * Aviso mientras una herramienta está activa.
 *
 * En las de consulta explica qué hacer. En las que modifican advierte además
 * que nada se guarda: lo que se dibuja o borra no llega todavía a la base, y
 * sin este aviso alguien podía trazar media red creyendo que estaba trabajando
 * y perderla al recargar, o creer que borró un registro real.
 */
export const TOOL_HINTS: Partial<Record<MapTool, string>> = {
  fiber: FIBER_HINT,
  node: "Click para agregar una cubierta. Lo dibujado no se guarda en la base todavía.",
  zone: "Click para dibujar la zona y doble click para terminar. No se guarda en la base todavía.",
  edit: "Click sobre un elemento para ver su información. Solo se mueve o se corrige si su capa está activa. Los cambios no se guardan en la base todavía.",
  delete: "Click sobre un elemento de la capa activa para quitarlo del mapa. No se borra de la base de datos.",
  conectividad: "Click sobre una cubierta de empalme para ver su conectividad. Otros elementos se ignoran.",
  sentido: "Click sobre una cubierta: sus cables de entrada y de salida quedan resaltados con los colores de la leyenda. Click sobre un cable para identificarlo. Click fuera para quitar la marca.",
  cable: "Click sobre un cable: se pinta de rojo y se marcan sus dos cubiertas, la de entrada y la de salida. Click fuera para quitarlo.",
}

/** Orden de la barra de herramientas; define también los atajos 1..8. */
export const TOOL_ORDER: MapTool[] = [
  "pan",
  "edit",
  "node",
  "fiber",
  "zone",
  "delete",
  "measure-length",
  "measure-area",
]
